use crate::fingerprint::FunctionFingerprint;

#[derive(Debug, Default, Clone, Copy)]
pub struct RawDimensions {
    pub ngram_sim: f64,
    pub ast_sim: f64,
    pub signature_sim: f64,
    pub param_type_sim: f64,
    pub type_usage_sim: f64,
    pub semantic_sim: f64,
    pub cf_sim: f64,
    pub api_sim: f64,
    pub tainted_api_sim: f64,
    pub motif_sim: f64,
    pub flow_sim: f64,
    pub cf_order_sim: f64,
    pub arg_type_sim: f64,
    pub literal_concat_sim: f64,
}

impl RawDimensions {
    pub fn weighted_score(&self, w: &[f64; 14]) -> f64 {
        self.ngram_sim * w[0]
            + self.ast_sim * w[1]
            + self.signature_sim * w[2]
            + self.param_type_sim * w[3]
            + self.type_usage_sim * w[4]
            + self.semantic_sim * w[5]
            + self.cf_sim * w[6]
            + self.api_sim * w[7]
            + self.tainted_api_sim * w[8]
            + self.motif_sim * w[9]
            + self.flow_sim * w[10]
            + self.cf_order_sim * w[11]
            + self.arg_type_sim * w[12]
            + self.literal_concat_sim * w[13]
    }

    pub fn as_array(&self) -> [f64; 14] {
        [
            self.ngram_sim,
            self.ast_sim,
            self.signature_sim,
            self.param_type_sim,
            self.type_usage_sim,
            self.semantic_sim,
            self.cf_sim,
            self.api_sim,
            self.tainted_api_sim,
            self.motif_sim,
            self.flow_sim,
            self.cf_order_sim,
            self.arg_type_sim,
            self.literal_concat_sim,
        ]
    }

    pub fn apply_semantic_override(&self, base_score: f64) -> f64 {
        let identity_gate = self
            .api_sim
            .max(self.semantic_sim)
            .max(self.ast_sim)
            .max(self.motif_sim);

        // Data flow paths are abstract (they hash SemanticMarkers like SqlSink, not raw strings).
        // Therefore, flow_sim generalizes across frameworks perfectly!
        // We drop the motif_sim requirement because motif hashes use exact API strings which don't cross frameworks.
        if self.flow_sim > 0.8 && identity_gate > 0.1 {
            return base_score.max(0.85);
        }
        base_score
    }
}

pub fn jaccard_sorted(a: &[u64], b: &[u64]) -> f64 {
    if a.is_empty() && b.is_empty() {
        return 0.0;
    }
    let mut intersection = 0;
    let mut i = 0;
    let mut j = 0;
    while i < a.len() && j < b.len() {
        if a[i] == b[j] {
            intersection += 1;
            i += 1;
            j += 1;
        } else if a[i] < b[j] {
            i += 1;
        } else {
            j += 1;
        }
    }
    let union = a.len() + b.len() - intersection;
    if union == 0 {
        0.0
    } else {
        (intersection as f64) / (union as f64)
    }
}

pub fn containment(candidate: &[u64], target: &[u64]) -> f64 {
    if candidate.is_empty() && target.is_empty() {
        return 0.0;
    }
    if target.is_empty() {
        return 0.0; // If target is empty, we cannot contain it. Return 0.0 so it doesn't hallucinate 1.0.
    }
    if candidate.is_empty() {
        return 0.0;
    }
    let mut intersection = 0;
    let mut i = 0;
    let mut j = 0;
    while i < candidate.len() && j < target.len() {
        if candidate[i] == target[j] {
            intersection += 1;
            i += 1;
            j += 1;
        } else if candidate[i] < target[j] {
            i += 1;
        } else {
            j += 1;
        }
    }
    (intersection as f64) / (target.len() as f64)
}

pub fn type_usage_overlap_sorted(a: &FunctionFingerprint, b: &FunctionFingerprint) -> f64 {
    if a.type_usages.is_empty() || b.type_usages.is_empty() {
        return 0.0;
    }
    // type_usages are Vec<String> — use sorted merge to avoid HashSet allocation
    let mut sa: Vec<&str> = a.type_usages.iter().map(|s| s.as_str()).collect();
    let mut sb: Vec<&str> = b.type_usages.iter().map(|s| s.as_str()).collect();
    sa.sort_unstable();
    sb.sort_unstable();
    let mut intersection = 0usize;
    let mut i = 0;
    let mut j = 0;
    while i < sa.len() && j < sb.len() {
        match sa[i].cmp(sb[j]) {
            std::cmp::Ordering::Equal => {
                intersection += 1;
                i += 1;
                j += 1;
            }
            std::cmp::Ordering::Less => i += 1,
            std::cmp::Ordering::Greater => j += 1,
        }
    }
    let union = sa.len() + sb.len() - intersection;
    if union == 0 {
        0.0
    } else {
        intersection as f64 / union as f64
    }
}

pub fn lcs_similarity(candidate: &[u64], target: &[u64]) -> f64 {
    let n = candidate.len();
    let m = target.len();
    if n == 0 || m == 0 {
        return 0.0;
    }
    // Prevent OOM: if sequence is too large, fallback to jaccard
    if n > 2000 || m > 2000 {
        return jaccard_sorted(candidate, target);
    }
    // Use O(min(N,M)) space: only need two rows
    let mut prev = vec![0; m + 1];
    let mut curr = vec![0; m + 1];
    for i in 1..=n {
        for j in 1..=m {
            if candidate[i - 1] == target[j - 1] {
                curr[j] = prev[j - 1] + 1;
            } else {
                curr[j] = std::cmp::max(prev[j], curr[j - 1]);
            }
        }
        prev.copy_from_slice(&curr);
    }
    let lcs = curr[m] as f64;
    let max_len = std::cmp::max(n, m) as f64;
    lcs / max_len
}

pub fn compute_dimensions(
    candidate: &FunctionFingerprint,
    target: &FunctionFingerprint,
) -> RawDimensions {
    // Fast path: identical fingerprint id means all dimensions are either 1.0 or 0.0
    // depending on the field types, but jaccard of identical sorted vecs = 1.0.
    // Skip the expensive DP paths.
    if crate::pattern::scorer::fingerprint_id(candidate)
        == crate::pattern::scorer::fingerprint_id(target)
    {
        return RawDimensions {
            ngram_sim: 1.0,
            ast_sim: 1.0,
            signature_sim: 1.0,
            param_type_sim: 1.0,
            type_usage_sim: 1.0,
            semantic_sim: 1.0,
            cf_sim: 1.0,
            api_sim: 1.0,
            tainted_api_sim: 1.0,
            motif_sim: 1.0,
            flow_sim: 1.0,
            cf_order_sim: 1.0,
            arg_type_sim: 1.0,
            literal_concat_sim: 1.0,
        };
    }

    let ngram_sim =
        if candidate.weighted_ngram_hashes.is_empty() || target.weighted_ngram_hashes.is_empty() {
            jaccard_sorted(&candidate.ngram_hashes, &target.ngram_hashes)
        } else {
            crate::pattern::scorer::weighted_jaccard(
                &candidate.weighted_ngram_hashes,
                &target.weighted_ngram_hashes,
            )
        };

    let semantic_sim = jaccard_sorted(&candidate.semantic_markers, &target.semantic_markers);

    let ast_sim = if !candidate.skeleton_hashes.is_empty()
        && !target.skeleton_hashes.is_empty()
        && ngram_sim > 0.25
    {
        1.0 - crate::ast_distance::tree_edit_distance(
            &candidate.skeleton_hashes,
            &target.skeleton_hashes,
        )
    } else {
        jaccard_sorted(&candidate.structural_markers, &target.structural_markers)
    };

    let signature_sim = jaccard_sorted(&candidate.signature_ngrams, &target.signature_ngrams);
    let param_type_sim = jaccard_sorted(&candidate.param_type_ngrams, &target.param_type_ngrams);
    let type_usage_sim = type_usage_overlap_sorted(candidate, target);
    let cf_sim = jaccard_sorted(&candidate.control_flow_hashes, &target.control_flow_hashes);

    let api_sim_full = jaccard_sorted(&candidate.api_calls, &target.api_calls);
    let api_sim_seg =
        if !candidate.api_call_segments.is_empty() && !target.api_call_segments.is_empty() {
            jaccard_sorted(&candidate.api_call_segments, &target.api_call_segments)
        } else {
            0.0
        };
    let api_sim = api_sim_full.max(api_sim_seg);

    let motif_sim = containment(&candidate.motif_hashes, &target.motif_hashes);
    let flow_sim = containment(
        &candidate.data_flow_path_hashes,
        &target.data_flow_path_hashes,
    );

    // Mutual empty should be 0.0 so the dimension carries no signal.
    let tainted_api_sim =
        if candidate.tainted_api_calls.is_empty() && target.tainted_api_calls.is_empty() {
            0.0
        } else if candidate.tainted_api_calls.is_empty() {
            0.0
        } else if target.tainted_api_calls.is_empty() {
            jaccard_sorted(&candidate.tainted_api_calls, &target.api_calls)
        } else {
            jaccard_sorted(&candidate.tainted_api_calls, &target.tainted_api_calls)
        };

    let cf_order_sim =
        if candidate.control_flow_sequence.is_empty() && target.control_flow_sequence.is_empty() {
            0.0
        } else {
            lcs_similarity(
                &candidate.control_flow_sequence,
                &target.control_flow_sequence,
            )
        };

    let arg_type_sim =
        if !candidate.argument_call_types.is_empty() && !target.argument_call_types.is_empty() {
            jaccard_sorted(&candidate.argument_call_types, &target.argument_call_types)
        } else {
            0.0
        };

    let literal_concat_sim = if !candidate.literal_pattern_hashes.is_empty()
        && !target.literal_pattern_hashes.is_empty()
    {
        jaccard_sorted(
            &candidate.literal_pattern_hashes,
            &target.literal_pattern_hashes,
        )
    } else {
        0.0
    };

    RawDimensions {
        ngram_sim,
        ast_sim,
        signature_sim,
        param_type_sim,
        type_usage_sim,
        semantic_sim,
        cf_sim,
        api_sim,
        motif_sim,
        flow_sim,
        tainted_api_sim,
        cf_order_sim,
        arg_type_sim,
        literal_concat_sim,
    }
}
