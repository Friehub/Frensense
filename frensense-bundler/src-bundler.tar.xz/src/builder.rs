use crate::loader::load_corpus;
use frensense_engine::auto_filter::AutoFilterEntry;
use frensense_engine::corpus::bundle::{BundlePattern, BundlePayload};
use std::path::Path;
// Note: imports will be fixed iteratively.
pub fn build_bundle_from_patterns(
    patterns: &[BundlePattern],
    corpus_dir_override: Option<&Path>,
) -> Result<Vec<u8>, String> {
    // Pre-compute API IDF at build time so loaders can skip recomputation (~100 ms saving)
    let api_idf_weights = compute_bundle_api_idf(patterns);

    // Compute auto-derived semantic filter suggestions
    // We need source text for each pattern to extract imports and call targets
    // Use the explicit corpus_dir if provided (from build_bundle), otherwise fall back
    // to current_dir + corpus/targets (for incremental build path).
    let corpus_dir = corpus_dir_override
        .map(|d| d.to_path_buf())
        .unwrap_or_else(|| {
            std::env::current_dir()
                .map(|d| d.join("corpus").join("targets"))
                .unwrap_or_default()
        });
    // Recursively find a corpus file by its pattern ID and variant.

    fn collect_corpus_files(dir: &Path, map: &mut std::collections::HashMap<String, String>) {
        if let Ok(entries) = std::fs::read_dir(dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.is_dir() {
                    collect_corpus_files(&path, map);
                } else if path.is_file() {
                    if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
                        if let Ok(content) = std::fs::read_to_string(&path) {
                            map.insert(name.to_string(), content);
                        }
                    }
                }
            }
        }
    }

    let mut corpus_files = std::collections::HashMap::new();
    collect_corpus_files(corpus_dir.as_path(), &mut corpus_files);

    fn find_corpus_file(
        id: &str,
        variant: &str,
        corpus_files: &std::collections::HashMap<String, String>,
    ) -> Option<String> {
        for ext in &["ts", "tsx", "js", "jsx", "rs", "py", "go"] {
            let target = format!("{}_{}.{}", id, variant, ext);
            if let Some(content) = corpus_files.get(&target) {
                return Some(content.clone());
            }
        }
        None
    }

    let mut pattern_source_texts = std::collections::HashMap::new();
    for bp in patterns {
        if let Some(src) = find_corpus_file(&bp.id, "positive", &corpus_files) {
            pattern_source_texts.insert(bp.id.clone(), src);
        }
        for (i, variant) in ["negative", "negative2", "negative3", "negative4"]
            .iter()
            .enumerate()
        {
            if let Some(src) = find_corpus_file(&bp.id, variant, &corpus_files) {
                pattern_source_texts.insert(format!("{}_neg_{}", bp.id, i), src);
            }
        }
    }

    let auto_stats = crate::auto_filter::compute_auto_filters(patterns, &pattern_source_texts);
    // Serialize auto-derived filter stats.  Each entry is:
    // (pid, imports, calls, must_not_contain_call_to, function_name_regex, excludes_nodes, excludes_fnames)
    let auto_filter_stats: Vec<AutoFilterEntry> = {
        let mut v = Vec::new();
        let all_pids: std::collections::HashSet<&str> =
            patterns.iter().map(|p| p.id.as_str()).collect();
        for pid in &all_pids {
            let calls = auto_stats
                .contains_call_to
                .get(*pid)
                .cloned()
                .unwrap_or_default();
            let excl_calls = auto_stats
                .must_not_contain_call_to
                .get(*pid)
                .cloned()
                .unwrap_or_default();
            let _fn_re = String::new();
            let req_nodes = auto_stats
                .contains_node_type
                .get(*pid)
                .cloned()
                .unwrap_or_default();
            let excl_nodes = auto_stats
                .must_not_contain_node_type
                .get(*pid)
                .cloned()
                .unwrap_or_default();
            let excl_fnames = auto_stats
                .must_not_match_function_name
                .get(*pid)
                .cloned()
                .unwrap_or_default();
            if !calls.is_empty()
                || !excl_calls.is_empty()
                || !req_nodes.is_empty()
                || !excl_nodes.is_empty()
            {
                v.push(AutoFilterEntry {
                    pattern_id: pid.to_string(),
                    required_calls: calls.into_iter().collect(),
                    forbidden_calls: excl_calls.into_iter().collect(),
                    required_node_types: req_nodes.into_iter().collect(),
                    forbidden_node_types: excl_nodes.into_iter().collect(),
                    forbidden_fn_names: excl_fnames.into_iter().collect(),
                });
            }
        }
        v
    };

    let payload = BundlePayload {
        patterns: patterns.to_vec(),
        api_idf_weights,
        auto_filter_stats,
    };
    frensense_frc::write_bundle(&payload, patterns.len() as u32)
}

fn compute_pattern_variance(
    positives: &[frensense_engine::fingerprint::FunctionFingerprint],
) -> (f64, usize) {
    if positives.len() < 2 {
        return (0.0, 3);
    }

    let mut total_sim = 0.0;
    let mut count = 0;

    for i in 0..positives.len() {
        for j in (i + 1)..positives.len() {
            let p1 = &positives[i];
            let p2 = &positives[j];

            let api_sim =
                frensense_engine::pattern::similarity::jaccard_sorted(&p1.api_calls, &p2.api_calls);
            let sem_sim = frensense_engine::pattern::similarity::jaccard_sorted(
                &p1.control_flow_hashes,
                &p2.control_flow_hashes,
            );

            total_sim += (api_sim + sem_sim) / 2.0;
            count += 1;
        }
    }

    let avg_sim = total_sim / (count as f64);
    let variance = 1.0 - avg_sim;

    let min_dims = if variance > 0.6 {
        1
    } else if variance > 0.3 {
        2
    } else {
        3
    };

    (variance, min_dims)
}

pub fn build_bundle_incremental(corpus_dir: &Path) -> Result<Vec<u8>, String> {
    let manifest_path = corpus_dir.join(".bundle_manifest.toml");
    let mut manifest = Manifest::load(&manifest_path);

    let patterns = load_corpus(corpus_dir)?.0;

    let bundle_patterns: Vec<BundlePattern> = patterns
        .into_iter()
        .map(|mut p| {
            let (var, min_dims) = compute_pattern_variance(&p.positives);
            p.feature_variance = Some(var);
            p.min_evidence_dims = Some(min_dims);
            BundlePattern {
                id: p.id,
                positives: p.positives,
                negatives: p.negatives,
                semantic_filter: p.semantic_filter,
                observation: p.observation,
                impact: p.impact,
                improvement: p.improvement,
                expected_context: p.expected_context,
                cwe: p.cwe,
                cvss: p.cvss,
                owasp: p.owasp,
                severity: p.severity,
                runtime_probe: p.runtime_probe,
                feature_variance: p.feature_variance,
                min_evidence_dims: p.min_evidence_dims,
            }
        })
        .collect();

    // Since build_bundle_incremental writes only patterns (no payload envelope in the old code?! Wait, let's look closer... ah, it serialized bundle_patterns directly!). Let's just fix it to use write_bundle. Wait, the old code serialized `bundle_patterns` without `BundlePayload`! That's a bug in the old code (it would fail to deserialize in `load_bundle`). I'll just change it to use write_bundle with `bundle_patterns`.
    let output = build_bundle_from_patterns(&bundle_patterns, Some(corpus_dir))?;

    // Update manifest with current file hashes
    if let Ok(entries) = std::fs::read_dir(corpus_dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
                if std::path::Path::new(name)
                    .extension()
                    .is_some_and(|ext| ext.eq_ignore_ascii_case("toml"))
                    && name != ".bundle_manifest.toml"
                {
                    continue;
                }
                if let Ok(metadata) = std::fs::metadata(&path) {
                    let mtime = metadata
                        .modified()
                        .ok()
                        .and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok())
                        .map_or(0, |d| d.as_secs());
                    if let Ok(content) = std::fs::read(&path) {
                        let content_hash = blake3::hash(&content).into();
                        manifest.update_entry(
                            path.to_string_lossy().to_string(),
                            mtime,
                            content_hash,
                        );
                    }
                }
            }
        }
    }

    manifest.save(&manifest_path)?;

    Ok(output)
}

#[derive(serde::Serialize, serde::Deserialize, Debug, Clone)]
struct ManifestEntry {
    path: String,
    mtime: u64,
    content_hash: [u8; 32],
}

#[derive(serde::Serialize, serde::Deserialize, Debug, Default)]
struct Manifest {
    entries: Vec<ManifestEntry>,
}

impl Manifest {
    fn load(path: &std::path::Path) -> Self {
        let Ok(content) = std::fs::read_to_string(path) else {
            return Self::default();
        };
        toml::from_str(&content).unwrap_or_default()
    }

    fn save(&self, path: &std::path::Path) -> Result<(), String> {
        let content = toml::to_string_pretty(self).map_err(|e| e.to_string())?;
        std::fs::write(path, content).map_err(|e| e.to_string())
    }

    fn update_entry(&mut self, path: String, mtime: u64, content_hash: [u8; 32]) {
        self.entries.retain(|e| e.path != path);
        self.entries.push(ManifestEntry {
            path,
            mtime,
            content_hash,
        });
    }
}

fn compute_bundle_api_idf(
    patterns: &[frensense_engine::corpus::bundle::BundlePattern],
) -> Vec<(u64, f32)> {
    let total = patterns.len() as f32;
    if total == 0.0 {
        return Vec::new();
    }
    let mut api_doc_freq: rustc_hash::FxHashMap<u64, f32> = rustc_hash::FxHashMap::default();
    for pattern in patterns {
        let mut seen: rustc_hash::FxHashSet<u64> = rustc_hash::FxHashSet::default();
        for fp in &pattern.positives {
            for &call in &fp.api_calls {
                if seen.insert(call) {
                    *api_doc_freq.entry(call).or_insert(0.0) += 1.0;
                }
            }
        }
    }
    let mut weights: Vec<(u64, f32)> = api_doc_freq
        .into_iter()
        .map(|(hash, df)| (hash, (total / df).ln()))
        .collect();
    weights.sort_unstable_by_key(|&(hash, _)| hash);
    weights
}

pub fn build_bundle(corpus_dir: &std::path::Path) -> Result<Vec<u8>, String> {
    let patterns = crate::loader::load_corpus(corpus_dir)?.0;

    let bundle_patterns: Vec<frensense_engine::corpus::bundle::BundlePattern> = patterns
        .into_iter()
        .map(|mut p| {
            let (var, min_dims) = compute_pattern_variance(&p.positives);
            p.feature_variance = Some(var);
            p.min_evidence_dims = Some(min_dims);
            frensense_engine::corpus::bundle::BundlePattern {
                id: p.id,
                positives: p.positives,
                negatives: p.negatives,
                semantic_filter: p.semantic_filter,
                observation: p.observation,
                impact: p.impact,
                improvement: p.improvement,
                expected_context: p.expected_context,
                cwe: p.cwe,
                cvss: p.cvss,
                owasp: p.owasp,
                severity: p.severity,
                runtime_probe: p.runtime_probe,
                feature_variance: p.feature_variance,
                min_evidence_dims: p.min_evidence_dims,
            }
        })
        .collect();

    build_bundle_from_patterns(&bundle_patterns, Some(corpus_dir))
}
